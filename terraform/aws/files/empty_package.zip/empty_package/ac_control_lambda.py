def lambda_handler(context):
    print("Hello World")
