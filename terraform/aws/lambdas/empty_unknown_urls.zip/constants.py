LOGIN_MONGO_PATH = "login.json"

MALICIOUS = "malicious_urls"
UNKNOWN = "unknown_urls"
